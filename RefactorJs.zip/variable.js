var baseurl = "http://fsapi.sarvaya.com/";
var apiurl = baseurl+"api/";
var id_token="";
var userObj;
var projectId=0;
var selectedAlbum=""
var storeIndexes =[];
var getFirstSelectedImageIndex;
var getLastSelectedImageIndex;
var getSelectedImagesIndex =[];
var keycode = null;
var assetName=""
